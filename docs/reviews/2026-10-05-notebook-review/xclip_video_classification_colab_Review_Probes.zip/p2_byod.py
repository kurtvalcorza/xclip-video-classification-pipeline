"""P2: cell 13's BYOD branch (google.colab stand-in), the per-split validate_dataset, check_split_disjoint and the
full training-split validation that follow it, on constructed zips of GIF clips (decoded by the carried
frames_from_animation) and MP4 clips (decoded by the carried decode_clip with PyAV 18.1.0, the pinned version).
Sweeps the clip count against the stated 'at least sixteen clips of at least two labels with at least two clips
each', and tests a source shared by two labels, a short clip, a missing file and an unlisted clip."""
import io, json, os, sys, types, zipfile, importlib, tempfile, contextlib
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('xclip_video_classification_pipeline'); pkg.__path__ = [str(repo / 'src/xclip_video_classification_pipeline')]
sys.modules['xclip_video_classification_pipeline'] = pkg
S = importlib.import_module('xclip_video_classification_pipeline.samples')
def gif(seed, n=8):
    rng = np.random.default_rng(seed)
    frames = [Image.fromarray(rng.integers(0, 255, (64, 80, 3), dtype=np.uint8)) for _ in range(n)]
    b = io.BytesIO(); frames[0].save(b, format='GIF', save_all=True, append_images=frames[1:], duration=80, loop=0); return b.getvalue()
def mp4(seed, n=12):
    import av
    b = io.BytesIO()
    with av.open(b, 'w', format='mp4') as c:
        s = c.add_stream('libx264', rate=12); s.width, s.height, s.pix_fmt = 64, 48, 'yuv420p'
        rng = np.random.default_rng(seed)
        for _ in range(n):
            for p in s.encode(av.VideoFrame.from_ndarray(rng.integers(0, 255, (48, 64, 3), dtype=np.uint8), format='rgb24')): c.mux(p)
        for p in s.encode(): c.mux(p)
    return b.getvalue()
def build(n, labels=('a', 'b'), shared_source=False, short=False, missing=False, unlisted=False, kind='gif'):
    m, rows = {}, ['file,label,source']
    for i in range(n):
        name = f'c{i:03d}.{kind}'; m[name] = (gif(i, 3 if short and i == 0 else 8) if kind == 'gif' else mp4(i))
        src = 'film1' if shared_source and i < 4 else f's{i}'
        rows.append(f'{name},{labels[i % len(labels)]},{src}')
    if missing: rows.append('ghost.gif,a,s99')
    if unlisted: m['extra.gif'] = gif(999)
    m['labels.csv'] = ('\n'.join(rows) + '\n').encode()
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for k, v in m.items(): z.writestr(k, v)
    return {'byod.zip': b.getvalue()}
nb = json.loads((repo / 'tutorials/xclip_video_classification_colab.ipynb').read_text())
c13 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
branch = '\n'.join(l[4:] for l in c13.split('if USE_BYOD:\n', 1)[1].split('\nelse:', 1)[0].splitlines())
after = c13.split("dataset_manifests = ", 1)[1].split('\nwrite_dataset_csv', 1)[0]
code = branch + '\ndataset_manifests = ' + after + '\n'
os.chdir(tempfile.mkdtemp())
def run(up):
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(up))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {k: getattr(S, k) for k in ('load_byod_dataset', 'validate_dataset', 'split_dataset', 'check_split_disjoint')}
    g.update(Path=Path, SPLIT_SEED=42)
    try:
        exec(code, g); return {'outcome': 'accepted', 'splits': g['disjoint'], 'labels': g['LABELS']}
    except BaseException as exc:
        return {'outcome': 'refused', 'error': f'{type(exc).__name__}: {exc}'[:220]}
res = {'stated_minimum': 'at least sixteen clips of at least two labels with at least two clips each (cell 0)', 'sweep_gif_2_labels': {}}
for n in (16, 18, 20, 22, 24, 26, 28):
    res['sweep_gif_2_labels'][n] = run(build(n))
res['mp4_24_clips'] = run(build(24, kind='mp4'))
res['shared_source_across_labels_30'] = run(build(30, shared_source=True))
res['three_frame_clip_30'] = run(build(30, short=True))
res['missing_file_30'] = run(build(30, missing=True))
res['unlisted_clip_30'] = run(build(30, unlisted=True))
res['cancelled_dialog'] = run({})
print(json.dumps(res, indent=1, default=str)); (out / 'p2.json').write_text(json.dumps(res, indent=1, default=str))
# Which splits receive a source shared by two labels, over several seeds (split_dataset groups by source within a label).
def where(seed, n=30):
    recs = S.load_byod_dataset(Path(tempfile.mkdtemp()) / 'x.zip') if False else None
    up = build(n, shared_source=True)
    p = Path(tempfile.mkdtemp()) / 'b.zip'; p.write_bytes(up['byod.zip'])
    recs = S.load_byod_dataset(p)
    sp = S.split_dataset(recs, seed=seed)
    placed = sorted({(name, r['label']) for name, part in sp.items() for r in part if r.get('source') == 'film1'})
    try:
        S.check_split_disjoint(sp); verdict = 'disjoint'
    except ValueError as exc:
        verdict = f'ValueError: {exc}'
    return {'film1_placed': placed, 'check_split_disjoint': verdict[:160]}
res['shared_source_by_seed'] = {seed: where(seed) for seed in range(6)}
print(json.dumps(res['shared_source_by_seed'], indent=1)); (out / 'p2.json').write_text(json.dumps(res, indent=1, default=str))
