"""P3: X-CLIP base/32 was trained fully supervised on Kinetics-400. Compare the ten sample labels with the
Kinetics-400 class list (DeepMind kinetics-i3d label_map.txt, fetched from raw.githubusercontent.com) to see how
far the notebook's 'zero-shot' frozen baseline is a test on classes the checkpoint was trained to recognise."""
import json, re, sys, types, importlib, urllib.request, hashlib
from pathlib import Path
repo, out = Path(sys.argv[1]), sys.argv[2]
pkg = types.ModuleType('xclip_video_classification_pipeline'); pkg.__path__ = [str(repo / 'src/xclip_video_classification_pipeline')]
sys.modules['xclip_video_classification_pipeline'] = pkg
S = importlib.import_module('xclip_video_classification_pipeline.samples')
URL = 'https://raw.githubusercontent.com/deepmind/kinetics-i3d/master/data/label_map.txt'
raw = urllib.request.urlopen(URL, timeout=30).read()
k400 = [l.strip() for l in raw.decode().splitlines() if l.strip()]
keys = {'brushing hair': ['brushing hair'], 'doing a cartwheel': ['cartwheel'], 'catching a ball': ['catching or throwing'], 'chewing': ['chew'],
        'clapping hands': ['clapping'], 'climbing': ['climbing', 'rock climbing'], 'climbing stairs': ['stairs'], 'diving into water': ['diving'],
        'drawing a sword': ['sword'], 'dribbling a basketball': ['dribbling basketball']}
res = {'k400_classes': len(k400), 'label_map_sha256': hashlib.sha256(raw).hexdigest(), 'per_sample_label': {}}
for label in S.SAMPLE_LABELS:
    hits = sorted({c for c in k400 for k in keys[label] if k in c})
    res['per_sample_label'][label] = hits
res['exact_or_near_exact'] = [l for l, h in res['per_sample_label'].items() if any(h_ in ('brushing hair', 'cartwheeling', 'clapping', 'dribbling basketball') for h_ in h)]
res['related_k400_class'] = [l for l, h in res['per_sample_label'].items() if h]
res['no_k400_match'] = [l for l, h in res['per_sample_label'].items() if not h]
print(json.dumps(res, indent=1)); json.dump(res, open(out, 'w'), indent=1)
